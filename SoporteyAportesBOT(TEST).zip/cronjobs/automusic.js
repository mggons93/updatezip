const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");
const ffmpeg = require("fluent-ffmpeg");
const yts = require("yt-search");

const musicList = JSON.parse(fs.readFileSync('./database/musiclist2000.json', 'utf8'));
const musicgroup = JSON.parse(fs.readFileSync('./database/musicgroup.json', 'utf8'));

let client = null;
let cronActivomusica = false; // Variable para controlar el estado de la tarea

function setClient(_client) {
    client = _client;
}

function sanitizeFilename(name) {
    return name.replace(/[<>:"/\\|?*]+/g, '').trim(); // Quitar caracteres no válidos para archivos en Windows
}

async function buscarYDescargarMusica() {
    if (!client) {
        console.log("❌ Cliente no definido.");
        return;
    }

    if (cronActivomusica) {
        console.log("⏳ Ya se está ejecutando la tarea. Esperando...");
        return;
    }

    cronActivomusica = true;

    const añosDisponibles = musicList.años;
    const artistasDisponibles = musicList.artistas;
    const metodo = musicList.metodo;
    const mediaTempPath = path.resolve('./media-TEMP');
    if (!fs.existsSync(mediaTempPath)) fs.mkdirSync(mediaTempPath, { recursive: true });

    const MAX_INTENTOS = 1;
    let intento = 0;
    let video = null;
    let artista, añoAleatorio;

    while (intento < MAX_INTENTOS && !video) {
        intento++;
        añoAleatorio = añosDisponibles[Math.floor(Math.random() * añosDisponibles.length)];
        artista = artistasDisponibles[Math.floor(Math.random() * artistasDisponibles.length)];
        busqueda = metodo[Math.floor(Math.random() * metodo.length)];
        console.log(`🎯 Intento ${intento}: ${artista} ${busqueda} (${añoAleatorio})`);

        let search = await yts(`${artista} ${busqueda} ${añoAleatorio}`);
        if (!search.videos.length) {
            console.log("❌ No se encontraron resultados en esta búsqueda.");
            continue;
        }

        // Buscar primer video menor a 15 minutos
        video = search.videos.find(v => v.seconds <= 900);
        if (!video) {
            console.log("⏩ Todos los videos encontrados duran más de 15 minutos. Reintentando...");
        }
    }

    if (!video) {
        console.log("❌ No se pudo encontrar un video válido tras varios intentos.");
        cronActivomusica = false;
        return;
    }

    const videoTitle = video.title || "Audio desconocido";
    console.log(`✅ Video válido encontrado: ${videoTitle}`);
    const url = video.url;

    const safeArtista = sanitizeFilename(artista);
    const safeTitle = sanitizeFilename(videoTitle);
    const audioTempPath = path.join(mediaTempPath, `audio_temp_${safeArtista}.webm`);
    const finalAudioPath = path.join(mediaTempPath, `audio_final_${safeArtista}.mp3`);

    console.log(`🔽 Descargando audio de: ${artista}`);
    exec(`yt-dlp -f "bestaudio" --user-agent "Mozilla/5.0" -o "${audioTempPath}" ${url}`, (err, stdout, stderr) => {
        if (err) {
            console.error("❌ Error al ejecutar yt-dlp:", err);
            cronActivomusica = false;
            return;
        }

        if (!fs.existsSync(audioTempPath)) {
            console.log("❌ No se encontró el archivo descargado.");
            cronActivomusica = false;
            return;
        }

        ffmpeg().input(audioTempPath)
            .audioCodec("libmp3lame")
            .audioBitrate("320k")
            .output(finalAudioPath)
            .on("end", async () => {
                console.log("✅ Conversión completada.");
                const mensaje = `*Disfruten su momento de descanso con una buena rola*\n\n${artista} - ${videoTitle}`;
                const gruposmusica = musicgroup.activos || [];

                for (const grupoId of gruposmusica) {
                    try {
                        await client.sendMessage(grupoId, { text: mensaje });
                        await client.sendMessage(grupoId, {
                            audio: fs.readFileSync(finalAudioPath),
                            mimetype: "audio/mpeg",
                            fileName: `${safeArtista}\n${safeTitle}.mp3`,
                            ptt: false
                        });
                        console.log(`✅ Enviado a ${grupoId}`);
                    } catch (err) {
                        console.error(`❌ Error al enviar a ${grupoId}:`, err);
                    }
                }

                if (fs.existsSync(audioTempPath)) fs.unlinkSync(audioTempPath);
                if (fs.existsSync(finalAudioPath)) fs.unlinkSync(finalAudioPath);

                cronActivomusica = false;
            })
            .on("error", (convErr) => {
                console.error("❌ Error en la conversión:", convErr);
                cronActivomusica = false;
            })
            .run();
    });
}

module.exports = { buscarYDescargarMusica, setClient };
