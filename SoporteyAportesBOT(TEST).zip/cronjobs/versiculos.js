const path = require("path");
const fs = require("fs");
const axios = require("axios");
const he = require("he");
const sharp = require("sharp");
const { createCanvas, loadImage, registerFont } = require("canvas");
const { pinterest2 } = require('../lib/scraper');
const logPath = path.join(__dirname, "../logs/versiculos.log");
const fondosPath = path.join(__dirname, "../lib/assets/versiculos/fondos");

let client; // Cliente global

registerFont(path.join(__dirname, "../lib/assets/fonts/Arial.ttf"), { family: "Arial" });

function setClient(_client) {
    client = _client;
}

async function descargarFondoAbstracto() {
    const temas = [
        "naturaleza",
        "colores abstractos",
        "pinturas abstractas",
        "gatitos",
        "paisajes surrealistas",
        "atardeceres artísticos",
        "arte digital",
        "arte moderno",
        "arte contemporáneo",
        "paisajes asiaticos",
        "montañas del mundo",
        "arte digital abstracto",
        "colores",
        "edificios",
        "ciudades"
    ];

    const temaSeleccionado = temas[Math.floor(Math.random() * temas.length)];
    console.log(`[Pinterest] 🔍 Tema seleccionado: ${temaSeleccionado}`);

    const resultados = await pinterest2(temaSeleccionado);
    if (!resultados.length) throw new Error("No se encontraron imágenes de Pinterest.");

    const url = resultados[Math.floor(Math.random() * resultados.length)];
    const extension = path.extname(new URL(url).pathname) || '.jpg';
    const nombreBase = `fondo_${Date.now()}`;
    const inputPath = path.join(fondosPath, `${nombreBase}${extension}`);
    const outputPath = path.join(fondosPath, `${nombreBase}.jpg`);

    const res = await axios.get(url, { responseType: "arraybuffer" });
    fs.writeFileSync(inputPath, res.data);

    if (extension === ".webp") {
        await sharp(inputPath).jpeg().toFile(outputPath);
        try {
            const archivos = await fs.promises.readdir(fondosPath);
            const webps = archivos.filter(file => file.endsWith(".webp"));
            for (const file of webps) {
                await fs.promises.rm(path.join(fondosPath, file), { force: true });
                console.log(`🧹 Archivo .webp eliminado: ${file}`);
            }
        } catch (err) {
            console.error("❌ Error al eliminar archivos .webp:", err.message);
        }
    } else {
        fs.renameSync(inputPath, outputPath);
    }

    // 🔄 Limpiar imágenes viejas y limitar a 5
    try {
        const archivos = await fs.promises.readdir(fondosPath);
        const ahora = Date.now();
        const maxDias = 5;

        const jpgs = archivos
            .filter(file => file.endsWith('.jpg'))
            .map(file => {
                const fullPath = path.join(fondosPath, file);
                const stats = fs.statSync(fullPath);
                return {
                    nombre: file,
                    tiempo: stats.mtimeMs,
                    edadDias: (ahora - stats.mtimeMs) / (1000 * 60 * 60 * 24)
                };
            });

        for (const jpg of jpgs) {
            if (jpg.edadDias > maxDias) {
                await fs.promises.rm(path.join(fondosPath, jpg.nombre), { force: true });
                console.log(`🧽 Imagen eliminada por antigüedad: ${jpg.nombre}`);
            }
        }

        const jpgsActualizados = (await fs.promises.readdir(fondosPath))
            .filter(file => file.endsWith('.jpg'))
            .map(file => ({
                nombre: file,
                tiempo: fs.statSync(path.join(fondosPath, file)).mtimeMs
            }))
            .sort((a, b) => b.tiempo - a.tiempo);

        const sobrantes = jpgsActualizados.slice(5);
        for (const s of sobrantes) {
            await fs.promises.rm(path.join(fondosPath, s.nombre), { force: true });
            console.log(`🗑️ Imagen eliminada por exceso: ${s.nombre}`);
        }

    } catch (err) {
        console.error("❌ Error al limpiar imágenes:", err.message);
    }

    return outputPath;
}

async function generarImagenConTexto(texto, referencia, fondoPath) {
    const fondo = await loadImage(fondoPath);
    const canvas = createCanvas(fondo.width, fondo.height);
    const ctx = canvas.getContext("2d");

    // 1. Dibujar el fondo
    ctx.drawImage(fondo, 0, 0, canvas.width, canvas.height);

    // 2. Overlay oscuro
    ctx.fillStyle = "rgba(0, 0, 0, 0.4)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 3. Determinar color del texto según el brillo promedio del centro
    const imageData = ctx.getImageData(canvas.width / 4, canvas.height / 4, canvas.width / 2, canvas.height / 2).data;
    let totalBrillo = 0;
    for (let i = 0; i < imageData.length; i += 4) {
        const r = imageData[i], g = imageData[i + 1], b = imageData[i + 2];
        totalBrillo += 0.299 * r + 0.587 * g + 0.114 * b;
    }
    const brilloPromedio = totalBrillo / (imageData.length / 4);
    const textoColor = brilloPromedio > 127 ? "#000000" : "#ffffff";

    // 4. Preparar texto
    let fontSize = 38;
    const margenX = 80;
    const margenY = 60;
    const maxWidth = canvas.width - margenX * 2;

    ctx.textAlign = "center";
    ctx.textBaseline = "top";

    const wrapText = (text, maxWidth, fontSize) => {
        ctx.font = `bold ${fontSize}px Arial`;
        const palabras = text.split(" ");
        const lineas = [];
        let linea = "";

        for (let palabra of palabras) {
            const temp = linea + palabra + " ";
            if (ctx.measureText(temp).width < maxWidth) {
                linea = temp;
            } else {
                lineas.push(linea.trim());
                linea = palabra + " ";
            }
        }
        if (linea) lineas.push(linea.trim());
        return lineas;
    };

    let lineas = wrapText(texto, maxWidth, fontSize);
    while (lineas.length > 8 && fontSize > 16) {
        fontSize -= 2;
        lineas = wrapText(texto, maxWidth, fontSize);
    }

    ctx.font = `bold ${fontSize}px Arial`;
    const lineHeight = fontSize + 12;
    const totalTextoAlto = lineas.length * lineHeight;

    // Centrado vertical dentro de márgenes
    let y = (canvas.height - totalTextoAlto) / 2;

    // 5. Sombra
    ctx.shadowColor = "rgba(0, 0, 0, 0.5)";
    ctx.shadowBlur = 6;

    ctx.fillStyle = textoColor;
    for (let l of lineas) {
        ctx.fillText(l, canvas.width / 2, y);
        y += lineHeight;
    }

    // 6. Referencia bíblica
    ctx.shadowBlur = 0;
    ctx.font = `18px Arial`;
    ctx.fillText(`(${referencia})`, canvas.width / 2, y + 20);

    return canvas.toBuffer();
}




/*async function generarImagenConTexto(texto, referencia, fondoPath) {
    const fondo = await loadImage(fondoPath);
    const canvas = createCanvas(fondo.width, fondo.height);
    const ctx = canvas.getContext("2d");

    // 1. Dibujar el fondo
    ctx.drawImage(fondo, 0, 0, canvas.width, canvas.height);

    // 2. Desvanecer la imagen con un overlay oscuro semitransparente
    ctx.fillStyle = "rgba(0, 0, 0, 0.4)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 3. Determinar color de texto según brillo
    const imageData = ctx.getImageData(canvas.width / 4, canvas.height / 4, canvas.width / 2, canvas.height / 2).data;
    let totalBrillo = 0;
    for (let i = 0; i < imageData.length; i += 4) {
        const r = imageData[i], g = imageData[i + 1], b = imageData[i + 2];
        totalBrillo += 0.299 * r + 0.587 * g + 0.114 * b;
    }
    const brilloPromedio = totalBrillo / (imageData.length / 4);
    const textoColor = brilloPromedio > 127 ? "#000000" : "#ffffff";

    // 4. Preparar texto
    let fontSize = 38;
    const margen = 80;
    const maxWidth = canvas.width - margen * 2;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    const wrapText = (text, maxWidth, fontSize) => {
        ctx.font = `bold ${fontSize}px Arial`;
        const palabras = text.split(" ");
        const lineas = [];
        let linea = "";

        for (let palabra of palabras) {
            const temp = linea + palabra + " ";
            if (ctx.measureText(temp).width < maxWidth) {
                linea = temp;
            } else {
                lineas.push(linea.trim());
                linea = palabra + " ";
            }
        }
        if (linea) lineas.push(linea.trim());
        return lineas;
    };

    let lineas = wrapText(texto, maxWidth, fontSize);
    while (lineas.length > 8 && fontSize > 16) {
        fontSize -= 2;
        lineas = wrapText(texto, maxWidth, fontSize);
    }

    // 5. Estilo del texto: sombra y fondo difuminado
    ctx.font = `bold ${fontSize}px Arial`;
    const lineHeight = fontSize + 12;
    const totalAlto = lineas.length * lineHeight + 80;
    let y = (canvas.height - totalAlto) / 2 + 40;

    ctx.shadowColor = "rgba(0, 0, 0, 0.5)";
    ctx.shadowBlur = 6;

    // Fondo difuminado (opcional, por si quieres un bloque más claro detrás del texto)
    // ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
    // ctx.fillRect(margen, y - 40, canvas.width - margen * 2, lineas.length * lineHeight + 100);

    ctx.fillStyle = textoColor;
    for (let l of lineas) {
        ctx.fillText(l, canvas.width / 2, y);
        y += lineHeight;
    }

    // 6. Referencia bíblica
    ctx.shadowBlur = 0;
    ctx.font = `18px Arial`;
    ctx.fillText(`(${referencia})`, canvas.width / 2, y + 20);

    return canvas.toBuffer();
}*/

const saludos = "./database/saludos.json";

// ✅ Obtener la base de datos de saludos
async function obtenerSaludos() {
    // Si el archivo no existe, se crea con una estructura vacía
    if (!fs.existsSync(saludos)) {
        fs.writeFileSync(saludos, JSON.stringify({ saludados: [], nosaludados: [] }, null, 2));
    }

    try {
        let data = JSON.parse(fs.readFileSync(saludos, "utf-8"));
        
        // Asegurar que siempre existan las claves necesarias
        if (!data.saludados || !Array.isArray(data.saludados)) data.saludados = [];
        if (!data.nosaludados || !Array.isArray(data.nosaludados)) data.nosaludados = [];

        return data;
    } catch (error) {
        console.error("❌ Error al leer saludos.json:", error);
        return { saludados: [], nosaludados: [] };
    }
}

async function enviarVersiculoDelDia() {
    if (!client) {
        console.error("❌ Cliente no inicializado para versículo del día.");
        return;
    }

    console.log("[CRON] 🚀 Iniciando tarea del versículo del día...");

    try {
        const res = await axios.get("https://www.biblegateway.com/votd/get/?format=json&version=RVR1960");
        const textoHtml = res.data.votd.text;
        const textoPlano = textoHtml.replace(/(<([^>]+)>)/gi, "").trim();
        const texto = he.decode(textoPlano);
        const referencia = res.data.votd.display_ref;

        const fondoNuevo = await descargarFondoAbstracto();
        const buffer = await generarImagenConTexto(texto, referencia, fondoNuevo);

        const mensaje = `📖 *Versículo del Día* (${referencia})`;

        // ✅ Esperar a obtener los grupos saludados correctamente
        const saludosData = await obtenerSaludos();
        const grupos = saludosData.saludados;

        for (let chatId of grupos) {
        try {
            await client.sendMessage(chatId, { image: buffer, caption: mensaje });
            console.log(`✅ Enviado a ${chatId}`);
            await new Promise(resolve => setTimeout(resolve, 2000)); // ⏱️ Espera 1 segundo
        } catch (err) {
            console.warn(`⚠️ No se pudo enviar a ${chatId}: ${err.message}`);
        }
        }

        const fecha = new Date().toLocaleString("es-CO", { timeZone: "America/Bogota" });
        const logMensaje = `[${fecha}] ${referencia} - ${texto.replace(/\n/g, " ")}\n`;
        fs.mkdirSync(path.dirname(logPath), { recursive: true });
        fs.appendFileSync(logPath, logMensaje);

        console.log("[LOG] ✅ Versículo del día enviado y registrado.");
    } catch (error) {
        console.error("❌ No se pudo obtener o enviar el versículo del día:", error);
        fs.appendFileSync(logPath, `[ERROR] ${new Date().toISOString()} - ${error}\n`);
    }
}

module.exports = {
    setClient,
    enviarVersiculoDelDia,
};
