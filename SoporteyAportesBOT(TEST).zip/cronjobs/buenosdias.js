const fs = require('fs');
const path = require('path');
const axios = require('axios');
const saludos = "./database/saludos.json"; // <-- esta es la variable correcta

function obtenerSaludos() {
    if (!fs.existsSync(saludos)) {
        fs.writeFileSync(saludos, JSON.stringify({ saludados: [], nosaludados: [] }, null, 2));
    }

    try {
        let data = JSON.parse(fs.readFileSync(saludos, "utf-8"));

        if (!data.saludados || !Array.isArray(data.saludados)) data.saludados = [];
        if (!data.nosaludados || !Array.isArray(data.nosaludados)) data.nosaludados = [];

        return data;
    } catch (error) {
        console.error("❌ Error al leer saludos.json:", error);
        return { saludados: [], nosaludados: [] };
    }
}

let client = null;
let cronActivoBuenosDias = false;
let cronActivoBuenasNoches = false;

function setClient(_client) {
    client = _client;
}

// ✅ Función para obtener el buffer de la imagen
async function downloadImageBuffer(url) {
    try {
        const response = await axios.get(url, { responseType: "arraybuffer" });
        return Buffer.from(response.data);
    } catch (error) {
        console.error("❌ Error al descargar la imagen:", error);
        return null;
    }
}

// ✅ Función para enviar mensajes a los grupos saludados
async function enviarMensajeSaludo(imagenUrl, mensajeTexto, tipo) {
    const saludos = obtenerSaludos();

    if (!client) {
        console.error("❌ El cliente de WhatsApp no está inicializado.");
        return;
    }

    if (!saludos || !Array.isArray(saludos.saludados) || saludos.saludados.length === 0) {
        console.log("⚠️ No hay grupos en la lista de saludados.");
        return;
    }

    const bufferImagen = await downloadImageBuffer(imagenUrl);
    if (!bufferImagen) return;

    console.log(`[LOG] Enviando mensaje de ${tipo} a los siguientes grupos:`);

    for (const chatId of saludos.saludados) {
        try {
            console.log(`- 📩 Enviando a ${chatId}...`);
            await client.sendMessage(chatId, { image: bufferImagen, caption: mensajeTexto });
            console.log(`✅ Enviado a ${chatId}`);
            await new Promise(resolve => setTimeout(resolve, 2000)); // ⏱️ Espera 2 segundo
        } catch (error) {
            console.error(`❌ Error al enviar el mensaje de ${tipo} a ${chatId}:`, error);
        }
    }

    console.log(`[LOG] Todos los mensajes de ${tipo} han sido enviados.`);
}

async function ejecutarComandoBuenosDias() {
    if (cronActivoBuenosDias) return;
    cronActivoBuenosDias = true;

    const mensaje = `*Buenos días a todos☀️*\n\n*Les desea su Administrador y el CHI BOT 👋🏻*\n*Dios los bendiga, que tengan un buen amanecer y bonito día laboral.*`;
    const imagenUrl = "https://i.ibb.co/YTh5kvw6/Chobits-Chii.jpg";

    await enviarMensajeSaludo(imagenUrl, mensaje, "Buenos Días");

    cronActivoBuenosDias = false;
}

async function ejecutarComandoBuenasNoches() {
    if (cronActivoBuenasNoches) return;
    cronActivoBuenasNoches = true;

    const mensaje = `*Buenas noches a todos 🌙💤*\n\n*Les desea su Administrador y el BOT CHI 👋🏻*\n*Dios los guarde y les conceda un descanso reparador.*`;
    const imagenUrl = "https://i.ibb.co/TB68tvFp/HD-wallpaper-chii-pretty-dress-blond-beautiful-adorable-sweet-nice-anime-hot-beauty-anime-girl-long.jpg";

    await enviarMensajeSaludo(imagenUrl, mensaje, "Buenas Noches");

    cronActivoBuenasNoches = false;
}

module.exports = {
    setClient,
    ejecutarComandoBuenosDias,
    ejecutarComandoBuenasNoches
};
