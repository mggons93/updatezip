// youtubeciberseguridad.js
require('../settings/config');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { CronJob } = require('cron');
const saludos = require('../database/saludos.json');
const LAST_VIDEO_PATH = './database/lastvideo.json';
const YOUTUBE_CHANNEL_API = `https://www.youtube.com/feeds/videos.xml?channel_id=${global.ytchannel}`;
const LOG_PATH = './logs/youtube.log';

let client = null;

function setClient(_client) {
    client = _client;
}

function logVideo(title, url) {
    const fecha = new Date().toLocaleString("es-CO", { timeZone: "America/Bogota" });
    const logEntry = `[${fecha}] 🎥 ${title}\n🔗 ${url}\n\n`;

    // Asegura que exista la carpeta de logs
    const logDir = path.dirname(LOG_PATH);
    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }

    fs.appendFileSync(LOG_PATH, logEntry, 'utf8');
}

async function sendMessageToWhatsApp(videoTitle, videoUrl, videoThumbnail) {
    try {
        if (!client) throw new Error("❌ Cliente WhatsApp no inicializado.");

        const message = {
            image: { url: videoThumbnail },
            caption: `📢 *Nuevo video sobre ciberseguridad* 🔥\n\n🎥 *${videoTitle}*\n🔗 ${videoUrl}`,
            footer: "YouTube • Ciberseguridad",
        };

        const { saludados } = saludos;
        for (let chatId of saludados) {
            try {
                await client.sendMessage(chatId, message);
                console.log(`✅ Enviado a ${chatId}`);
                await new Promise(resolve => setTimeout(resolve, 1500)); // 🕐 Espera 1 segundo antes del siguiente
            } catch (err) {
                console.warn(`⚠️ No se pudo enviar a ${chatId}: ${err.message}`);
            }
        }

        // 📁 Registrar en log
        logVideo(videoTitle, videoUrl);

    } catch (error) {
        console.error("❌ Error al enviar mensaje:", error);
    }
}


async function verificarNuevoVideo() {
    try {
        const { data } = await axios.get(YOUTUBE_CHANNEL_API);
        const match = data.match(/<entry>[\s\S]*?<link rel="alternate" href="(.*?)"\/>[\s\S]*?<media:title>(.*?)<\/media:title>[\s\S]*?<media:thumbnail url="(.*?)"/);

        if (!match) return console.warn("⚠️ No se encontró información del video.");
        const [_, videoUrl, videoTitle, videoThumbnail] = match;

        let lastVideoUrl = "";
        if (fs.existsSync(LAST_VIDEO_PATH)) {
            const saved = JSON.parse(fs.readFileSync(LAST_VIDEO_PATH, 'utf8'));
            lastVideoUrl = saved.url || "";
        }

        if (videoUrl !== lastVideoUrl) {
            console.log("🆕 Nuevo video detectado:", videoTitle);
            await sendMessageToWhatsApp(videoTitle, videoUrl, videoThumbnail);
            fs.writeFileSync(LAST_VIDEO_PATH, JSON.stringify({
                url: videoUrl,
                title: videoTitle,
                thumbnail: videoThumbnail
            }, null, 2));
        } else {
            console.log("⏳ No hay videos nuevos.");
        }
    } catch (error) {
        console.error("❌ Error verificando video:", error);
    }
}

module.exports = {
    setClient,
    verificarNuevoVideo
};
