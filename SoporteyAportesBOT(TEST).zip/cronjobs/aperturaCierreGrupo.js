require('../settings/config');
const fs = require('fs');
const path = require('path');
const logFilePath = './log/whatsappinfo.log';

let client = null;
let cronActivoApertura = false;
let cronActivoCierre = false;

function setClient(_client) {
    client = _client;
}

// Función para registrar logs en un archivo
function registrarLog(mensaje) {
    const logMessage = `[${new Date().toLocaleString()}] ${mensaje}\n`;
    fs.appendFileSync(logFilePath, logMessage, 'utf8');
    console.log(logMessage.trim());
}

// ✅ Función para cambiar permisos del grupo solo si es necesario
async function cambiarPermisosGrupo(permitirMensajes) {
    try {
        if (!client) {
            registrarLog("❌ Client no inicializado.");
            return;
        }

        if (permitirMensajes && cronActivoApertura) {
            registrarLog("⚠️ Apertura ya en proceso.");
            return;
        }

        if (!permitirMensajes && cronActivoCierre) {
            registrarLog("⚠️ Cierre ya en proceso.");
            return;
        }

        // ⚙️ Obtener estado actual del grupo
        const metadata = await client.groupMetadata(global.groupsya);
        const esGrupoAbierto = metadata.announce === false; // false: abierto, true: cerrado

        if (permitirMensajes && esGrupoAbierto) {
            registrarLog("📌 El grupo ya está abierto. No se realizó ninguna acción.");
            return;
        }

        if (!permitirMensajes && !esGrupoAbierto) {
            registrarLog("📌 El grupo ya está cerrado. No se realizó ninguna acción.");
            return;
        }

        if (permitirMensajes) cronActivoApertura = true;
        else cronActivoCierre = true;

        registrarLog(`🔁 Ejecutando tarea: ${permitirMensajes ? 'Abrir grupo' : 'Cerrar grupo'}`);
        await client.groupSettingUpdate(global.groupsya, permitirMensajes ? 'not_announcement' : 'announcement');
        registrarLog(`✅ Grupo ${permitirMensajes ? 'habilitado' : 'deshabilitado'} para mensajes.`);

    } catch (err) {
        registrarLog(`❌ Error al cambiar permisos: ${err.message}`);
    } finally {
        if (permitirMensajes) cronActivoApertura = false;
        else cronActivoCierre = false;
    }
}

// Crear carpeta de logs si no existe
if (!fs.existsSync(path.dirname(logFilePath))) {
    fs.mkdirSync(path.dirname(logFilePath), { recursive: true });
    registrarLog("📂 Carpeta de logs creada.");
}

module.exports = {
    setClient,
    cambiarPermisosGrupo
};
