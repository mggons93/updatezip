const fs = require('fs');
const path = require('path');
const axios = require('axios'); // Asegúrate de tener axios instalado

// ✅ Función para obtener el buffer de la imagen
async function downloadImageBuffer(url) {
    try {
        const response = await axios.get(url, { responseType: "arraybuffer" });
        return Buffer.from(response.data);
    } catch (error) {
        logEnArchivo(`❌ Error al descargar la imagen: ${error.message}`);
        return null;
    }
}

// 📝 Log personalizado en ./logs/baneos.log
function logEnArchivo(mensaje) {
    const logDir = path.resolve(__dirname, '../../logs');
    const logPath = path.join(logDir, 'baneos.log');

    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }

    const timestamp = new Date().toLocaleString('es-CO', { timeZone: 'America/Bogota' });
    const linea = `[${timestamp}] ${mensaje}\n`;

    fs.appendFileSync(logPath, linea, 'utf8');
}

let cronActivoBaneos = false;
let client = null;

function setClient(_client) {
    client = _client;
}

function leerContadorJSON() {
    try {
        const data = fs.readFileSync('./database/contador.json', 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        logEnArchivo(`[ERROR] No se pudo leer contador.json: ${error.message}`);
        return {};
    }
}

async function ejecutarMensajeBaneos() {
    if (cronActivoBaneos) return;
    cronActivoBaneos = true;

    logEnArchivo("🕘 Cron de baneos iniciado");

    try {
        const grupos = leerContadorJSON();

        if (!grupos || Object.keys(grupos).length === 0) {
            logEnArchivo(`⚠️ No hay grupos activos en contador.json`);
            return;
        }

        for (const grupoId in grupos) {
            const teks = `*⚠️ MENSAJE IMPORTANTE: BANEOS*\n\nSe les recuerda que:\n\n🚫 se viene el baneo por que no estes activo o por que no has ayudado en el grupo.`;
            const baneosImg = await downloadImageBuffer("https://i.ibb.co/Kc1J5tBL/R.jpg");

            if (baneosImg && client) {
                await client.sendMessage(grupoId, { image: baneosImg, caption: teks });
                logEnArchivo(`✅ Mensaje de baneos enviado al grupo ${grupoId}`);
            } else {
                logEnArchivo(`⚠️ No se pudo enviar mensaje al grupo ${grupoId}`);
            }
        }

    } catch (error) {
        logEnArchivo(`❌ ERROR durante ejecución: ${error.message}`);
    } finally {
        cronActivoBaneos = false;
        logEnArchivo("🛑 Cron de baneos finalizado");
    }
}

module.exports = {
    setClient,
    ejecutarMensajeBaneos
};
