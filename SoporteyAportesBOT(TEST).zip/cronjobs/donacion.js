require('../settings/config');
const fs = require('fs');
const path = './database/contador.json';
const pathLog = './logs/donacion.log';
const axios = require('axios');
const ownerNumber = global.owner ; // Reemplaza por el número correcto

let client = null;
let cronActivoDonacion = false;

function setClient(_client) {
    client = _client;
}

const DB = './database/contador.json';
const leerContadorJSON = () => {
    if (!fs.existsSync(DB)) {
        fs.writeFileSync(DB, JSON.stringify({}, null, 2));
    }
    return JSON.parse(fs.readFileSync(DB));
};

// Función para guardar los datos del contador
const guardarContador = (contador) => {
    fs.writeFileSync(DB, JSON.stringify(contador, null, 2));
};

function logEnArchivo(mensaje) {
    const timestamp = new Date().toISOString();
    fs.appendFileSync(pathLog, `[${timestamp}] ${mensaje}\n`);
}

// ✅ Función para obtener el buffer de la imagen
async function downloadImageBuffer(url) {
    try {
        const response = await axios.get(url, { responseType: "arraybuffer" });
        return Buffer.from(response.data);
    } catch (error) {
        logEnArchivo(`❌ Error al descargar la imagen: ${error.message}`);
        return null;
    }
}

async function ejecutarComandoDonacion() {
    if (cronActivoDonacion) return;
    cronActivoDonacion = true;

    const grupos = leerContadorJSON();
    const gruposValidos = {};

    try {
        for (const grupoId in grupos) {
            try {
                const teks = `*🤝 ¡Apoya el Proyecto!*\n\n*Agradecemos tu colaboración para mantener el servicio activo y mejorar cada día. Cualquier donación es bienvenida 🙏.*\n\n💳 *Métodos de donación:*\n- *PayPal:* https://cutt.ly/DonacionSyA\n- *Nequi:* ${ownerNumber}\n- *Binance:*\n14FBn1ufBxs3xTBZ1Gm6Q3xB4GxF2n5aGm\n¡Gracias por tu apoyo!`;

                const donacionImg = await downloadImageBuffer("https://image.freepik.com/free-vector/donation_16734-172.jpg");

                await client.sendMessage(grupoId, { image: donacionImg, caption: teks });
                console.log(`[LOG] Mensaje de donación enviado al grupo ${grupoId}`);

                gruposValidos[grupoId] = grupos[grupoId];

            } catch (err) {
                console.error(`[ERROR] No se pudo enviar al grupo ${grupoId}:`, err?.message || err);
                if (err?.output?.statusCode === 403 || err?.message?.includes("forbidden")) {
                    console.warn(`⚠️ Acceso prohibido al grupo ${grupoId}. Será removido de contador.json.`);
                } else {
                    gruposValidos[grupoId] = grupos[grupoId];
                }
            }
        }

    } catch (error) {
        console.error("[ERROR] Fallo general al enviar mensajes de donación:", error);
    } finally {
        guardarContador(gruposValidos);
        cronActivoDonacion = false;
    }
}

module.exports = {
    setClient,
    ejecutarComandoDonacion
};
