{
  "build": "24H2",
  "version": "106.9"
}