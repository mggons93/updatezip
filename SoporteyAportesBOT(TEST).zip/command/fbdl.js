const fetch = require('node-fetch');
const handler = async (m, { text, client }) => {
    if (!text) {
        return client.sendMessage(m.chat, { text: 'Por favor, proporciona el enlace del video.' }, { quoted: m });
    }

    try {
        const response = await fetch(`https://api.vreden.web.id/api/fbdl?url=${encodeURIComponent(text)}`);
        const result = await response.json();

        if (!result || !result.data || (!result.data.hd_url && !result.data.sd_url)) {
            return client.sendMessage(m.chat, { text: 'Error 😿. Verifica el enlace o intenta más tarde.' }, { quoted: m });
        }

        const { hd_url, sd_url, title, durasi } = result.data;
        const videoUrl = hd_url || sd_url;

        await client.sendMessage(
            m.chat,
            {
                video: { url: videoUrl },
                caption: `🎥 *Título:* ${title}\n⏳ *Duración:* ${durasi}`,
            },
            { quoted: m }
        );
    } catch (error) {
        console.error(error);
        client.sendMessage(m.chat, { text: 'Ocurrió un error al procesar tu solicitud.' }, { quoted: m });
    }
};

handler.help = ['fb <url>'];
handler.tags = ['downloader'];
handler.command = ['facebook'];
